# Version 1 (frozen 9 October 2026)

Read docs/VERSION_1.md first: what was built, why, and what was learned. docs/ENCODER_RESEARCH_PLAN.md is the full research record.

- compiler/: the deterministic text compiler (Python reference, C++ native, tests) and every experiment script.
- dictionaries/: the fitted 8k dictionary used by the best models (hash 9967d692c6bafc80), two phrase dictionaries, the standard-BPE merges used as the traditional baseline.
- models/: ladder1_hash4096x4096.pt, the dictionary-free hash-encoder model with its reverse map (talks with `python compiler/experiments/chat.py models/ladder1_hash4096x4096.pt`, after copying hash4096x4096.json beside it); learn_by_reading.pt, the best-configuration core trained without Jane Austen (its exact tables are rebuilt from the corpus with `chat.py --data`).
- results/: every result file, with corpus manifests.

Requirements: Python 3.12+, numpy, torch; g++ for the native encoder. Build the corpus with compiler/experiments/prepare_books.py.
